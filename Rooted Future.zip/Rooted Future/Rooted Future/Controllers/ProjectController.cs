﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Rooted_Future.Data;
using Rooted_Future.Models;

namespace Rooted_Future.Controllers
{
    public class ProjectController : Controller
    {
        private readonly ApplicationDbContext _context;

        // Constructor to inject ApplicationDbContext
        public ProjectController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: /Project/Index
        public async Task<IActionResult> Index()
        {
            var projects = await _context.Projects.Include(p => p.Donations).Include(p => p.Volunteers).ToListAsync();
            return View(projects);
        }

        // GET: /Project/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Project/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Project project)
        {
            if (ModelState.IsValid)
            {
                // Add the new project to the database
                _context.Add(project);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(project);
        }

        // GET: /Project/Details/{id}
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var project = await _context.Projects
                .Include(p => p.Donations)
                .Include(p => p.Volunteers)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (project == null)
            {
                return NotFound();
            }

            return View(project);
        }
    }
}