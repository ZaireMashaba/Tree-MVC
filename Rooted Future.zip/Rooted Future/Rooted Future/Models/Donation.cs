﻿using System.ComponentModel.DataAnnotations;

namespace Rooted_Future.Models
{
	public class Donation
	{
		public int Id { get; set; }

		[Required]
		[Range(0.01, double.MaxValue, ErrorMessage = "Donation amount must be greater than 0.")]
		public decimal Amount { get; set; }

		[Required]
		public DateTime DonationDate { get; set; }

		// Foreign key for the associated project
		[Required]
		public int ProjectId { get; set; }
		public Project? Project { get; set; }

		// Foreign key for the user who made the donation
		public string? UserId { get; set; }
		public User? User { get; set; }
	}
}