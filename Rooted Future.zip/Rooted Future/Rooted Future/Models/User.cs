﻿using Microsoft.AspNetCore.Identity;

namespace Rooted_Future.Models
{
	public class User : IdentityUser
	{
		// Projects the user has volunteered for
		public ICollection<Project> VolunteeredProjects { get; set; } = new List<Project>();

		// Donations made by the user
		public ICollection<Donation> Donations { get; set; } = new List<Donation>();
	}
}