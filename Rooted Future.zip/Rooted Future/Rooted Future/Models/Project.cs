﻿using System.ComponentModel.DataAnnotations;

namespace Rooted_Future.Models
{

	public class Project
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; }

        [Required]
        [StringLength(1000)]
        public string Description { get; set; }

        public string Status { get; set; }

        [Required]
        public string Location { get; set; }

        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? EndDate { get; set; }

        // Added properties for cosmetic purposes
        public int VolunteerCount { get; set; }
        public decimal DonationAmount { get; set; }

        public ICollection<Donation> Donations { get; set; }
        public ICollection<User> Volunteers { get; set; }
    }
}