﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Rooted_Future.Data.Migrations
{
    /// <inheritdoc />
    public partial class two : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "DonationGoal",
                table: "Projects",
                newName: "DonationAmount");

            migrationBuilder.AddColumn<string>(
                name: "Location",
                table: "Projects",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "VolunteerCount",
                table: "Projects",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Location",
                table: "Projects");

            migrationBuilder.DropColumn(
                name: "VolunteerCount",
                table: "Projects");

            migrationBuilder.RenameColumn(
                name: "DonationAmount",
                table: "Projects",
                newName: "DonationGoal");
        }
    }
}
