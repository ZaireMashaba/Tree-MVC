﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SOEN6222_ST10291916.Models
{
    public class Donation
    {
        public int Id { get; set; }

        [Required]
        public string? UserId { get; set; }

        [Required]
        public decimal Amount { get; set; }

        public int ProjectId { get; set; }

        public DateTime DonationDate { get; set; }

        [ForeignKey("ProjectId")]
        public Project Project { get; set; }
    }
}