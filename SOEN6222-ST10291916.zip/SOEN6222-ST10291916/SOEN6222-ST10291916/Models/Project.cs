﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SOEN6222_ST10291916.Models
{
    public class Project
    {
        public int Id { get; set; }

        [Required]
        public string? Name { get; set; }

        public string? Description { get; set; }

        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }

        public bool IsOngoing { get; set; }

        public int VolunteerCount { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalDonations { get; set; }
    }
}