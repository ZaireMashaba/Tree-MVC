﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SOEN6222_ST10291916.Data;
using SOEN6222_ST10291916.Models;

namespace SOEN6222_ST10291916.Controllers
{
    public class ProjectsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public ProjectsController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Projects
        public IActionResult Index()
        {
            var projects = _context.Projects.ToList();
            return View(projects);
        }

        // GET: Projects/Details/5
        public IActionResult Details(int id)
        {
            var project = _context.Projects.FirstOrDefault(p => p.Id == id);
            if (project == null)
            {
                return NotFound();
            }

            project.VolunteerCount = _context.ProjectUsers.Count(pu => pu.ProjectId == id);
            project.TotalDonations = _context.Donations.Where(d => d.ProjectId == id).Sum(d => d.Amount);
            _context.SaveChanges();

            return View(project);
        }

        // POST: Projects/SignUp/5
        [Authorize]
        [HttpPost]
        public IActionResult SignUp(int projectId)
        {
            var userId = _userManager.GetUserId(User);

            if (!_context.ProjectUsers.Any(pu => pu.ProjectId == projectId && pu.UserId == userId))
            {
                var projectUser = new ProjectUser { ProjectId = projectId, UserId = userId };
                _context.ProjectUsers.Add(projectUser);
                _context.SaveChanges();
            }

            return RedirectToAction(nameof(Details), new { id = projectId });
        }

        // GET: Projects/Create (Admin only)
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Projects/Create
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult Create(Project project)
        {
            if (ModelState.IsValid)
            {
                _context.Projects.Add(project);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(project);
        }

        // GET: Projects/Edit/5 (Admin only)
        [Authorize(Roles = "Admin")]
        public IActionResult Edit(int id)
        {
            var project = _context.Projects.Find(id);
            return project == null ? NotFound() : View(project);
        }

        // POST: Projects/Edit
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult Edit(Project project)
        {
            var existingProject = _context.Projects.Find(project.Id);
            if (existingProject != null && ModelState.IsValid)
            {
                existingProject.Name = project.Name;
                existingProject.Description = project.Description;
                existingProject.StartDate = project.StartDate;
                existingProject.EndDate = project.EndDate;
                existingProject.IsOngoing = project.IsOngoing;
                existingProject.VolunteerCount = project.VolunteerCount; 

                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(project);
        }
    }
}