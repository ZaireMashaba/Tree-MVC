﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using SOEN6222_ST10291916.Data;
using SOEN6222_ST10291916.Models;

namespace SOEN6222_ST10291916.Controllers
{
    [Authorize]
    public class DonationsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public DonationsController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // POST: Donations/Create
        [HttpPost]
        public IActionResult Create(int projectId, decimal amount)
        {
            var userId = _userManager.GetUserId(User);
            var donation = new Donation
            {
                ProjectId = projectId,
                Amount = amount,
                UserId = userId,
                DonationDate = DateTime.Now
            };

            _context.Donations.Add(donation);
            _context.Projects.Find(projectId).TotalDonations += amount;
            _context.SaveChanges();

            return RedirectToAction("Details", "Projects", new { id = projectId });
        }
    }
}